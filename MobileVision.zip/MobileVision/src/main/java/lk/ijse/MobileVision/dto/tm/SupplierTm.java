package lk.ijse.MobileVision.dto.tm;


import javafx.collections.ObservableList;
import lombok.*;


@AllArgsConstructor
@NoArgsConstructor
@Data

public class SupplierTm {
    private String tel;
    private String name;
    private String address;
    private String id;
}
