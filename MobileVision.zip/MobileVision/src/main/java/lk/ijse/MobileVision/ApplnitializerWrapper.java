package lk.ijse.MobileVision;

public class ApplnitializerWrapper {
    public static void main(String[] args) {
        Applnitializer.main(args);
    }
}
